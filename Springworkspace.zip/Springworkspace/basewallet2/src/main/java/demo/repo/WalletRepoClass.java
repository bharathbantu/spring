package demo.repo;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import demo.beans.Customer;
@Repository
public class WalletRepoClass implements WalletRepo{
@Resource(name="map")
	private Map<String,Customer> data;

/*	public WalletRepoClass(Map<String, Customer> data2) {
		// TODO Auto-generated constructor stub
	this.data=data2;
	}*/

	
	public boolean save(Customer c) {
		data.put(c.getMobileNumber(),c);
		
		return true;
	}

	
	public Customer findOne(String mobileNumber) {
		
		return data.get(mobileNumber);
	}

	
	
	

}
