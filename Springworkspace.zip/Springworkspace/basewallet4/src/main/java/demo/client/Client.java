package demo.client;

import java.util.HashMap;
import java.util.Map;

import demo.beans.Customer;
import demo.repo.WalletRepo;
import demo.repo.WalletRepoClass;
import demo.service.WalletService;
import demo.service.WalletServiceClass;

public class Client {
	public static void main(String[] args) {
		Map<String,Customer> data=new HashMap<>();
		WalletRepo repo=new WalletRepoClass(data);
		WalletService service=new WalletServiceClass(repo);
	
		
	//	service.createAccount("suraj", "1234567891", 80000);
	// 	System.out.println(service.showBalance("1234567891"));
	//	service.createAccount("Ravuri", "1234567891", 50000);
	//	service.createAccount("Aditya", "12345678", 20000);
	//	service.createAccount("Akhilesh", "1234567", 30000);
		System.out.println(service.showBalance("12345678"));	
	//	System.out.println(service.showBalance("123456789"));
	//	System.out.println(service.showBalance("12345678332"));
		
	//	service.deposit("12345678", 1000);
		service.withDraw("12345678", 1000);
		System.out.println(service.showBalance("12345678"));
		/*service.withDraw("123456789", 12000);
		System.out.println(service.showBalance("123456789"));
		*/
		
	}

}
