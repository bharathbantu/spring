package demo.client;
import java.util.HashMap;
import java.util.Map;

import javax.xml.ws.Service;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Repository;

import demo.beans.Customer;
import demo.service.WalletService;
import demo.repo.WalletRepo;
@Configuration
@ComponentScan(basePackages="demo")
public class AppConfig {

	@Bean(value="map")
	public Map<String,Customer> getMap(){
		return new HashMap<String,Customer>();
	}
	@Bean(value="repo")
	public  demo.repo.WalletRepo getRepo(){
		return new demo.repo.WalletRepoClass(getMap());
	}
	@Bean(value="service")
	public demo.service.WalletService getService() {
		return new demo.service.WalletServiceClass(getRepo());
	}
}
